#ifndef P_SETTINGGENERAL_H
#define P_SETTINGGENERAL_H

#include <PacModel/presentation.h>
#include <QObject>
#include <QWidget>
#include "c_setting_general.h"

class C_SettingGeneral;
class P_SettingGeneral : public Presentation {
  //  Q_OBJECT
 private:
  QWidget *zone;

 public:
  P_SettingGeneral(Control *ctrl, QWidget *zone);
  QObject *getZone(int zoneId);
};

#endif  // P_SETTINGGENERAL_H
