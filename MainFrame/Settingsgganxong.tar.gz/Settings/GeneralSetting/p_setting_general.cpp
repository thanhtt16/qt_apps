#include "p_setting_general.h"

/**
     * Generic method to override for updating the presention.
     **/

P_SettingGeneral::P_SettingGeneral(Control *ctrl, QWidget *zone)
    : Presentation(ctrl) {
  this->zone = zone;
}

QObject *P_SettingGeneral::getZone(int zoneId) {
  switch (zoneId) {
    case 1:
      return Q_NULLPTR;
    default:
      return Q_NULLPTR;
  }
}
