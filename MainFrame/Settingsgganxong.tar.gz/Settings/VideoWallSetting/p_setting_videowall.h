#ifndef P_SETTINGVIDEOWALL_H
#define P_SETTINGVIDEOWALL_H

#include <PacModel/presentation.h>
#include <QComboBox>
#include <QLabel>
#include <QObject>
#include <QVBoxLayout>
#include <QWidget>
#include "c_setting_videowall.h"
class C_SettingVideoWall;
class P_SettingVideoWall : public Presentation {
  Q_OBJECT
 private:
  QWidget *zone;

 public:
  P_SettingVideoWall(Control *ctrl, QWidget *zone);
  void changeControl(Control *ctrl);
  void update();

  QObject *getZone(int zoneId);
 private Q_SLOTS:
  void selectedTransition(int index);
  void selectedTimeDelay(int index);

#endif  // P_SETTINGVIDEOWALL_H
