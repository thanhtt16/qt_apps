#include "p_setting_videowall.h"

/**
     * Generic method to override for updating the presention.
     **/

P_SettingVideoWall::P_SettingVideoWall(Control *ctrl, QWidget *zone)
    : Presentation(ctrl) {
  this->zone = zone;
  this->zone->setStyleSheet("color:#4c4b52");
  QVBoxLayout *mainLayout = new QVBoxLayout();
  mainLayout->setAlignment(Qt::AlignCenter | Qt::AlignTop);
  this->zone->setLayout(mainLayout);

  QWidget *firstWidget = new QWidget(this->zone);
  QHBoxLayout *firstLayout = new QHBoxLayout();
  firstWidget->setFixedHeight(80);

  firstWidget->setLayout(firstLayout);
  mainLayout->addWidget(firstWidget);

  QWidget *leftWidget = new QWidget(firstWidget);
  QVBoxLayout *leftLayout = new QVBoxLayout();
  leftWidget->setLayout(leftLayout);
  firstLayout->addWidget(leftWidget);

  QLabel *labeltransition = new QLabel(leftWidget);
  labeltransition->setText("Bắt đầu quá trình chuyển đổi");
  leftLayout->addWidget(labeltransition);
  QComboBox *comboBoxTransition = new QComboBox(leftWidget);
  comboBoxTransition->addItem(tr("Khi nhấp chuột"));
  connect(comboBoxTransition, &QComboBox::currentIndexChanged, this,
          &P_SettingVideoWall::selectedTransition);
  comboBoxTransition->addItem(tr("Tự động"));
  leftLayout->addWidget(comboBoxTransition);

  QWidget *rightWidget = new QWidget(firstWidget);
  QVBoxLayout *rightLayout = new QVBoxLayout();
  rightWidget->setLayout(rightLayout);
  firstLayout->addWidget(rightWidget);

  QLabel *labelDelay = new QLabel(rightWidget);
  labelDelay->setText("Thời gian trì hoãn");
  rightLayout->addWidget(labelDelay);

  QComboBox *comboBoxDelay = new QComboBox(rightWidget);
  comboBoxDelay->addItem(tr("5s"));
  comboBoxDelay->addItem(tr("10s"));
  comboBoxDelay->addItem(tr("20s"));
  connect(comboBoxDelay, &QComboBox::currentIndexChanged, this,
          &P_SettingVideoWall::selectedTimeDelay);
  rightLayout->addWidget(comboBoxDelay);
}

void P_SettingVideoWall::selectedTransition(int index) {
  //  switch (index) {
  //    case 0: {
  //      qDebug() << "Tự động";

  //    } break;
  //    case 1: {
  //    } break;
  //    default:
  //      break;
  //  }
}

void P_SettingVideoWall::selectedTimeDelay(int index) {
  //  switch (index) {
  //    case 0: {
  //      qDebug() << "5s";
  //    } break;
  //    case 1: {
  //      qDebug() << "10s";

  //    } break;
  //    case 2: {
  //      qDebug() << "20s";
  //    } break;
  //    default:
  //      break;
  //  }
}

void P_SettingVideoWall::update() {}

QObject *P_SettingVideoWall::getZone(int zoneId) {
  switch (zoneId) {
    case 1:
      return Q_NULLPTR;
    default:
      return Q_NULLPTR;
  }
}
