#ifndef P_SETTINGPLAYBACK_H
#define P_SETTINGPLAYBACK_H

#include <PacModel/presentation.h>
#include <QAction>
#include <QComboBox>
#include <QDesktopWidget>
#include <QDialog>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QGridLayout>
#include <QLabel>
#include <QMenu>
#include <QMimeDatabase>
#include <QObject>
#include <QProgressDialog>
#include <QPushButton>
#include <QString>
#include <QStringList>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QWidget>
#include "c_setting_playback.h"
class C_SettingPlayBack;
class P_SettingPlayBack : public Presentation {
  //  Q_OBJECT
 private:
  QWidget *zone;

 public:
  P_SettingPlayBack(Control *ctrl, QWidget *zone);
  void update();

  QObject *getZone(int zoneId);

 private Q_SLOTS:
  void browse();
  void find();
  void animateFindClick();
  void openFileOfItem(int row, int column);
  void contextMenu(const QPoint &pos);

 private:
  QStringList findFiles(const QStringList &files, const QString &text);
  void showFiles(const QStringList &files);
  QComboBox *createComboBox(const QString &text = QString());
  void createFilesTable();

  QComboBox *fileComboBox;
  QComboBox *textComboBox;
  QComboBox *directoryComboBox;
  QLabel *filesFoundLabel;
  QPushButton *findButton;
  QTableWidget *filesTable;

  QDir currentDir;
};

#endif  // P_SETTINGPLAYBACK_H
