﻿#include "RTCPlayer.h"

// NTBON 3:59 14/9

RTCDownloader *RTCPlayer::getRtpDownloader() const
{
    return rtpDownloader;
}



QNetworkAccessManager *RTCPlayer::getNaManager() const
{
    return naManager;
}


CamItemType RTCPlayer::getType() const
{
    return type;
}

RTCPlayer::RTCPlayer(QWidget *zone) {
    this->zone = zone;
    this->zone->installEventFilter(this);

    mainLayout = new QVBoxLayout(this->zone);
    mainLayout->setSpacing(0);
    mainLayout->setMargin(0);
    this->zone->setLayout(mainLayout);

    topbarSpaceHolder = new QWidget(this->zone);
    topbarSpaceHolder->setStyleSheet("background-color: #111;");
    mainLayout->addWidget(topbarSpaceHolder);

    videoZone = new QWidget(this->zone);
    videoZone->setStyleSheet("background-color: black;");
    videoZone->move(0,30);
    videoZone->resize(this->zone->width(), this->zone->height() - 30);
    mainLayout->addWidget(videoZone);

    topbarSpaceHolder->setFixedHeight(30);

    rtpQueue.setName("RTP Queue" + playerName);
    imageQueue.setName("Image Queue "  + playerName);

    type.protocol = "WS";
    type.network = "CDN";
    type.name = "SD";

    naManager = new QNetworkAccessManager(this);
    rtpDownloader = new RTCDownloader(this, naManager);

    // RTP package builder
    pRTCSplitter = new RTCSplitter(this);


    // LIVE open a socket to receive link continuously and then download it
    pRTCSocket = new RTCSocket(this);
    connect(pRTCSocket, &RTCSocket::socketConnected, this, &RTCPlayer::onSocketConnected);
    connect(pRTCSocket, &RTCSocket::socketDisconnected, this, &RTCPlayer::onSocketDisconnected);
    connect(pRTCSplitter, &RTCSplitter::shouldReopenSouce, getPRTCSocket(), &RTCSocket::openSocket);

    pRTCRenderer = new RTCRender(this);
    pRTCRenderer->startWorking();

    pRTCRendererWidget = new RTCRenderWidget(videoZone);
    pRTCRenderer->setRendererWidget(pRTCRendererWidget);

    //    connect(pRTCRenderer, &RTCRender::startPlaying, this, &RTCPlayer::onPlayerPlaying);
    connect(pRTCRenderer, &RTCRender::showLoadingSign, this, &RTCPlayer::onShowLoadingSign);
    connect(pRTCRenderer, &RTCRender::showPlayerLayer, this, &RTCPlayer::onShowPlayerLayer);
    //connect(pRTCRenderer, &RTCRender::hidePlayerNoCamera, this, &RTCPlayer::showNoCameraLayer);
}

void RTCPlayer::stopWorking() {
    //    qDebug() << "RTCPlayer::rtcPlayerStop============ STOP ALL WORKER";

}

void RTCPlayer::startWorking() {
    pRTCSplitter->startWorking();

    //    QString playerName = "Player " + getPlayerName();
    //    qDebug() << playerName << "::RTCPlayer::rtcPlayerStart::START ALL" ;

}

void RTCPlayer::playSource() {
    startWorking();
    type.name = this->camItem->getIsMain() ? "HD" : "SD";

    if (this->camItem != Q_NULLPTR) {
        CamStream *camStream = camItem->getCamStream(this->type);
        if (camStream){
            QString newSource = camStream->getSource();
            if (!this->sourceUrl.isEmpty() && !newSource.isEmpty()) {
                if (this->sourceUrl == newSource) {
                    qDebug() << playerName << ":::P_Cam9RTCPlayer::setNewSource::SAME SOURCE";
                    return; // do nothing with the same same source
                }
            }
            this->pRTCSocket->openSource(newSource);
        }else{
            //            this->pRTCSocket->openSource("");
        }

    } else {
        Q_EMIT showWallLayer();
    }
}


//detect link
//void RTCPlayer::playSource() {
//    startWorking();
////    type.name = this->camItem->getIsMain() ? "HD" : "SD";
//    bool isMain = this->camItem->getIsMain();
//    if (this->camItem != Q_NULLPTR) {
//        //        CamStream *camStream = camItem->getCamStream(this->type);
//        camItem->getAvailableCamStream(isMain, [this](CamStream *camStream){
//            if (camStream){
//                QString newSource = camStream->getSource();
////                qDebug() << "CAMSTREAM SELECTED " <<  camStream->getProtocol() << camStream->getNetwork() << camStream->getSource();
//                if (!this->sourceUrl.isEmpty() && !newSource.isEmpty()) {
//                    if (this->sourceUrl == newSource) {
//                        qDebug() << playerName << ":::P_Cam9RTCPlayer::playSource::SAME SOURCE";
//                        return; // do nothing with the same same source
//                    }
//                }
//                this->pRTCSocket->openSource(newSource);
//            }/*else {
//                this->pRTCSocket->openSource("");
//            }*/
//        } , [this](){
//            qDebug() << "Can't not get camstream";
//        });
//    } else {
//        Q_EMIT showWallLayer();
//    }
//}


void RTCPlayer::onSocketConnected() {
}

void RTCPlayer::onSocketDisconnected() {
    qDebug() <<Q_FUNC_INFO<< "=================================================================";
    qDebug() << "RTCPlayer::onSocketDisconnected=========================== SOCKET DISCONNECTED";
    qDebug() << "==============================================================================";
}

void RTCPlayer::onShowLoadingSign() {
    Q_EMIT showLoadingSign();
}

void RTCPlayer::onShowPlayerLayer() {
    Q_EMIT showPlayerLayer();
}

void RTCPlayer::onShowWallLayer() {
    Q_EMIT showWallLayer();
}

void RTCPlayer::wheelEventZoomVideo(QVariant *dataStruct) {
    pRTCRendererWidget->wheelEventZoomVideo(dataStruct);
}

void RTCPlayer::eventMoveVideo(QVariant *dataStruct) {
    pRTCRendererWidget->eventMoveVideo(dataStruct);
}

RTCSplitter *RTCPlayer::getPRTCSplitter() const
{
    return pRTCSplitter;
}

QString RTCPlayer::getSourceUrl() const
{
    return sourceUrl;
}

void RTCPlayer::setSourceUrl(const QString &value)
{
    sourceUrl = value;
}

void RTCPlayer::newAction(int message, QVariant *attachment) {
    switch (message) {
    case Message.APP_NETWORK_IS_REACHABLE:
    case Message.APP_NETWORK_IS_UNREACHABLE: {
        this->getPRTCSocket()->newAction(message, attachment);
    } break;

    case Message.PLAYER_SOURCE_CLEAR: {
        this->setSourceUrl("");
        this->pRTCSocket->closeSource();
        pRTCSplitter->stopWorking();
    } break;

    case Message.PLAYER_PLAY_LIVE_SD: {
        this->camItem->setIsMain(false);
        pRTCSplitter->stopWorking();
        playSource();
    } break;

    case Message.PLAYER_PLAY_LIVE_HD: {
        this->camItem->setIsMain(true);
        pRTCSplitter->stopWorking();
        playSource();

    } break;

    case Message.PLAYER_NEW_LIVE_SOURCE_SET: {
        this->camItem = attachment->value<CamItem *>();
        pRTCSplitter->stopWorking();
        playSource();
    } break;

    case Message.HIDE: {
        this->zone->hide();
    } break;

    case Message.SHOW: {
        this->zone->show();
    } break;

    case Message.WHEEL_EVENT_ZOOM_VIDEO: {
        wheelEventZoomVideo(attachment);
    } break;

    case Message.EVENT_MOVE_ZOOM_VIDEO: {
        eventMoveVideo(attachment);
    } break;

    default:
        qDebug() << "ERROR : General Internal pac action in RTCPlayer "
                 << "non-catched :" + Message.toString(message);
    }
}

bool RTCPlayer::eventFilter(QObject *watched, QEvent *event) {
    QWidget *sender = qobject_cast<QWidget *>(watched);
    if (sender != Q_NULLPTR && sender == this->zone) {
        switch (event->type()) {
        case QEvent::Resize: {
            QResizeEvent *resizeEvent = (QResizeEvent *)(event);
            QSize newSize = resizeEvent->size();
            topbarSpaceHolder->move(0,0);
            topbarSpaceHolder->setFixedHeight(30);
            videoZone->move(0,30);
            this->videoZone->resize(newSize.width(), newSize.height() - 30);

        } break;

        default:
            break;
        }
    }
    return true;
}

RTCPlayer::~RTCPlayer() {
    delete mainLayout;
    delete pRTCSocket;
    delete pRTCSplitter;
    delete pRTCRenderer;
    delete pRTCRendererWidget;
}
