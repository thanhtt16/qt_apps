﻿#include "RTCSplitter.h"
int RTCSplitter::countPlayer = 0;
RTCPlayer *RTCSplitter::getPRTCPlayer() const
{
    return pRTCPlayer;
}

RTCSplitter::RTCSplitter(RTCPlayer *rtcPlayer) {
    NALUStartCode.append((char)0);
    NALUStartCode.append((char)0);
    NALUStartCode.append((char)0);
    NALUStartCode.append((char)1);
    IDR_NAL_TYPE.append(101);

    this->pRTCPlayer = rtcPlayer;
    this->pRTCPlayer->setPlayerName(QString::number(countPlayer));
    /* register all the codecs */
    avcodec_register_all();
    /*Register codecs, devices and formats*/
    av_register_all();
    av_log_set_level(AV_LOG_DEBUG);
    //Initialize network, this is new from april 2013, it will initialize the RTP
    avformat_network_init();
    //    decoderOpen();

    playerName = QString::number(countPlayer);
    countPlayer++;
    this->setObjectName("Decoder");
}
void RTCSplitter::enqueueImageDecode(long timestamp, QImage image){
    Cam9ImageQueue & imageQueue = this->pRTCPlayer->getImageQueue();
    if (!image.isNull())
        imageQueue.enqueue(timestamp, image);
}

RTCSplitter::~RTCSplitter() {
    decoderClose();
}

void RTCSplitter::startWorking() {
    decoderOpen();
    if (!isRunning()) {
        QThread::start();
    }
}

void RTCSplitter::stopWorking() {
    if(avCodecContext && avCodecContext->internal && avCodecContext->refcounted_frames != 0){
        avcodec_flush_buffers (avCodecContext);
    }
    //    QThread::quit();
}

void RTCSplitter::run() {
    //    QString playerName = "Player " + this->pRTCPlayer->getPlayerName();

    Cam9MapQueue& rtpQueue = this->pRTCPlayer->getRtpQueue();
    rtpQueue.setName("RTP Queue of " + this->pRTCPlayer->getPlayerName());

    //    qDebug() << "SIZE RTp" << rtpQueue.getSize();

    int HEADER_LENGTH = 12;
    bool IDRPictureStarted = false;
    QByteArray IDRPicture;
    qDebug() << playerName <<  "::RTCSplitter::run ";
    double old = 0;
    Q_UNUSED(old)
    QString oldHex = "";

    while (isRunning()) {

        //        qDebug() << "PLAYER NAME _ SPLITTER" << playerName;

        QByteArray rawData = dequeueWithTimeout(downloadTimeWait);

        //        qDebug() << "START _ RAWDATA";

        QString rootPath =  QDir::homePath() + "/" + "imageVideoWall/RawData";
        if (!QDir(rootPath).exists()) {
            QDir().mkpath(rootPath);
        }
        //        if(playerName == "0") {
        //            QList<int> listValue;
        //            bool ok;
        //            for (int index = 0; index < rawData.size(); ++index) {

        //                int value = rawData.mid(index, 1).toHex().toInt(&ok,16);
        //                listValue.append(value);
        //            }

        //            QString data;
        //            for (int index = 0; index < listValue.size(); ++index) {
        //                data += QString::number(listValue.at(index));
        //                if(index  < listValue.size() - 1) data += ",";
        //            }

        //            QString filePath = rootPath + "/" + "rawdata1.txt";
        //            QFile file(filePath);
        //            file.open(QIODevice::Append);
        //            QTextStream(&file) << data;
        //            file.close();

        ////            qDebug() << "H264 __ " << listValue;
        ////            qDebug() << "\n ********************END RAW DATA**********************" << listValue.size();

        //        }



        if (!rawData.isEmpty()) {
            long passedBytes = 0;
            bool rtpIsOk = true;
            while (isRunning() && passedBytes < rawData.size() && rtpIsOk) {
                bool ret;
                int payloadSize = rawData.mid(passedBytes + 0, 2).toHex().toInt(&ret,16);
                long long timeslong =  rawData.mid(passedBytes + 2, 8).toHex().toLongLong(0, 16);
                double timestampDouble = reinterpret_cast<double&>(timeslong);
                int index = rawData.mid(passedBytes + 10, 2).toHex().toInt(&ret,16);
                QString timeStampString = QString::number(timestampDouble, 'g', 19);
                long timestampKey  = timeStampString.toLong();


                //                if(playerName == "0") {
                //                    qDebug() << "payloadSize****" << payloadSize;
                //                    qDebug() << "TimeStamp******" <<  timeslong  << timestamp <<QString::number(timestamp, 'g', 19);
                //                    qDebug() << "index**********" << index;
                //                }


                Q_UNUSED(index)
                // Phần data h264 bị ngắn hơn chiều dài.
                int lengthOfH264RawData = payloadSize - 10;
                if (passedBytes + HEADER_LENGTH + lengthOfH264RawData > rawData.size()) {
                    rtpIsOk = false;
                    qDebug() << playerName << " something went wrong... in RTP passedBytes + HEADER_LENGTH + lengthOfH264RawData=" << (passedBytes + HEADER_LENGTH + lengthOfH264RawData) << "/" << rawData.size();
                    continue;
                    break;
                }

                QByteArray h264Raw = rawData.mid(passedBytes + HEADER_LENGTH, lengthOfH264RawData);

                //                if(playerName == "0") {
                //                    QList<int> listValue;
                //                    bool ok;
                //                    for (int index = 0; index < h264Raw.size(); ++index) {

                //                        int value = h264Raw.mid(index, 1).toHex().toInt(&ok,16);
                //                        listValue.append(value);
                //                    }
                //                    qDebug() << "H264 __ " << listValue;
                //                    qDebug() << "\n ********************END H264**********************" << listValue.size();

                //                }


                passedBytes = passedBytes + payloadSize + 2;// cong 2byte length cua h264

                // h264 processing
                int nalu_header_byte = h264Raw.mid(0, 1).toHex().toInt(&ret,16);

                //                if(playerName == "0"){
                //                    qDebug() << "NALU HEADER _ BYTE" << nalu_header_byte;
                //                }

                int nalType = nalu_header_byte & 0b11111;
                //                qDebug() << "rtp[" << index << "].naluByte=" << nalu_header_byte << ".naluType=" << (nalType & 0b11111);
                switch (nalType) {
                case 7: // SPS Type
                    decodeRTPPackage(NALUStartCode + h264Raw);
                    break;
                case 8: // PPS Type
                    decodeRTPPackage(NALUStartCode + h264Raw);
                    break;
                case 5: // IDR Type - 101
                    onReceiveRTPPackage(timestampKey, NALUStartCode + h264Raw);
                    break;
                case 28: { // IDR Picture Type MULTIPLE PART
                    int FU_A_byte = h264Raw.mid(1, 1).toHex().toInt(&ret,16);
                    int naluPayloadType = FU_A_byte & 0b11111;
                    Q_UNUSED(naluPayloadType)
                    if (FU_A_byte & 0b10000000) {//124 & 69
                        IDRPicture  = IDR_NAL_TYPE + h264Raw.mid(2, payloadSize - 10);
                        IDRPictureStarted = true;
                    } else{
                        if (FU_A_byte & 0b01000000) { // end of Fragment Unit 5
                            if (IDRPictureStarted == false) {
                                rtpIsOk = false;
                                break;
                            }
                            IDRPicture = IDRPicture + h264Raw.mid(2, payloadSize - 10);
                            onReceiveRTPPackage(timestampKey, NALUStartCode + IDRPicture);
                            IDRPictureStarted = false; // end of IDR Picture
                        } else {
                            if (IDRPictureStarted == false) {
                                rtpIsOk = false;
                                break;
                            }
                            IDRPicture = IDRPicture + h264Raw.mid(2, payloadSize - HEADER_LENGTH);
                        }
                    }
                }
                    break;


                case 1: { // P-Frame  Pictur Type
                    onReceiveRTPPackage(timestampKey, NALUStartCode + h264Raw);
                }
                    break;

                case 0: { // End Of 10 minute type
                    //qDebug() << playerName << " end of 10 minutes ";
                }
                    break;
                default:
                    qDebug() << playerName << " something went wrong... in RTP passedBytes=" << passedBytes << "/" << rawData.size() << " nalType=" << nalType;
                    //rtpIsOk = false;
                    break;
                }

            }
            this->sequenceOfTimeooutPackage = 0;
        } else { // no data after timeout
            if (this->sequenceOfTimeooutPackage >= 30000) { // if no data received after 20 second then do reconnect
                this->sequenceOfTimeooutPackage = 0;
                //                Q_EMIT shouldReopenSouce();
            }
        }
    }
    qDebug() << playerName << "::RTCSplitter::STOPPED ";
}

void RTCSplitter::liveWorker() {

}

QByteArray RTCSplitter::dequeueWithTimeout(long timeout) {
    Cam9MapQueue& rtpQueue = this->pRTCPlayer->getRtpQueue();
    QByteArray rtpData;
    while (isRunning() && (timeout > 0) ) {
        rtpData = rtpQueue.dequeue();
        if (!rtpData.isEmpty()) {
            break;
        }

        if (rtpData.isEmpty()) {
            QThread::msleep(100);
            timeout = timeout - 100;

            //            if (rtpQueue.getSize() > 5) {
            //                qDebug() << "RTCSplitter::dequeueWithTimeout::bypass rtp pkt at " << downloadTimeWait - timeout;
            //                break;
            //            }
        }
    }

    this->sequenceOfTimeooutPackage += downloadTimeWait - timeout;
    if (rtpData.isEmpty() && rtpQueue.getSize() != 0) rtpQueue.next();
    return rtpData;
}

QImage RTCSplitter::decode2Image(QByteArray h264Data) {
    //    QString playerName = "Player " + this->pRTCPlayer->getPlayerName();

    QImage image;
    if (h264Data.size() > 0) {
        // h264 processing
        bool ret;
        int nalu_header_byte = h264Data.mid(4, 1).toHex().toInt(&ret,16);
        int nalType = nalu_header_byte & 0b11111;
        switch (nalType) {
        case 7: { // SPS Type
            decodeRTPPackage(h264Data);
        } break;
        case 8: { // PPS Type
            decodeRTPPackage(h264Data);
        }
            break;
        case 5: { // IDR Typ
            try {
                image = decodeRTPPackage(h264Data);
            } catch (QException e) {qDebug() << e.what(); }
        }
            break;

        case 1: { // P-Frame  Pictur Type
            image = decodeRTPPackage(h264Data);
        }
            break;
        default:
            qDebug() << playerName << " something went wrong... in H264";
            break;
        }
    }
    return image;
}

void RTCSplitter::onReceiveRTPPackage(long timestamp, QByteArray h264Package) {
    //        QString playerName = "Player " + this->pRTCPlayer->getPlayerName();
    //        qDebug() << playerName << " Thread: " << this->thread()
    //                 << "RTCSplitter onReceiveRTPPackage - packageIndex: " << rtpPackageIndex;
    Cam9ImageQueue & imageQueue = this->pRTCPlayer->getImageQueue();
    QImage image = decode2Image(h264Package);
    if (!image.isNull()){
        imageQueue.enqueue(timestamp, image);
    }else{
        if(playerName == "10"){
            qDebug() << "Enqueue Image NULL";
        }
    }

}

double RTCSplitter::get_fps(AVCodecContext *avctx){
    return 1.0 / av_q2d(avctx->time_base) / FFMAX(avctx->ticks_per_frame, 1);
}

QImage RTCSplitter::decodeRTPPackage(QByteArray rtpPackage) {
    QImage image;
    int rtpSize = rtpPackage.size();
    bool ret;
    int nalu_header_byte = rtpPackage.mid(4, 1).toHex().toInt(&ret,16);


    quint8 *data = new quint8[rtpSize];
    memcpy(data, rtpPackage.constData(), rtpSize);
    //Create packet
    AVPacket avPacket;
    //allocate packet memory
    int initPackage = av_new_packet(&avPacket, rtpSize);
    av_init_packet(&avPacket);

    if (rtpSize > 0 && initPackage == 0) {


        avPacket.size = rtpSize;
        avPacket.data = data;
        //        if(avPacket.data != 0) return image;

        AVFrame *avFrame = av_frame_alloc();
        if(avFrame == NULL)
        {
            qDebug("Unable to allocate frames\n");
        }

        struct SwsContext *swsContext = NULL;
        int decodedFrameSize = 0, decodedFrameCount = 0;
        decodedFrameSize = avcodec_decode_video2(avCodecContext, avFrame, &decodedFrameCount, &avPacket);
        if(playerName == "10") {qDebug() << "WIDTH CONTEXT" <<avCodecContext->width <<avCodecContext->height <<"SIZE PACKAGE" <<  rtpSize<< "decodedFrameSize"<< decodedFrameSize<< "decodedFrameCount"<< decodedFrameCount;}
        if (decodedFrameSize > 0 && decodedFrameCount > 0) {
            //            avFrame->quality = 4;
            //            SWS_BICUBIC
            // Create context

            int width = avCodecContext->width;
            int height = avCodecContext->height;

            if(swsContext == NULL && width > 0 && height > 0){
                swsContext = sws_getContext(width,
                                            height,
                                            avCodecContext->pix_fmt,
                                            avCodecContext->width,
                                            avCodecContext->height,
                                            AV_PIX_FMT_RGB24,
                                            SWS_FAST_BILINEAR,
                                            NULL, NULL, NULL);


                uint8_t *outBuffer = (uint8_t *)av_malloc(avpicture_get_size(
                                                              AV_PIX_FMT_RGB24, avCodecContext->width, avCodecContext->height));
                AVPicture avPicture;
                // Fill picture with image
                // pixels is a unsigned char buffer
                avpicture_fill(&avPicture, outBuffer, AV_PIX_FMT_RGB24,
                               avCodecContext->width, avCodecContext->height);

                // Convert frame
                int v_scale_result =  sws_scale(swsContext, (const uint8_t *const *)avFrame->data,
                                                avFrame->linesize, 0, avCodecContext->height,
                                                avPicture.data, avPicture.linesize);
                Q_UNUSED(v_scale_result);

                image = QImage(avPicture.data[0],
                        avFrame->width,
                        avFrame->height,
                        avPicture.linesize[0],
                        QImage::Format_RGB888).copy();

                //            if(playerName == "1"){
                //                QString rootPath =  QDir::homePath() + "/" + "imageVideoWall";
                //                if (!QDir(rootPath).exists()) {
                //                    QDir().mkpath(rootPath);
                //                }

                //                QString filename =  rootPath + "/" + QString::number(QDateTime::currentMSecsSinceEpoch()) + ".png";
                //                qDebug() << "FILENAME" <<filename;
                //                image.save(filename);

                //            }

                if (image.isNull() || image.height() <= 0) {
                    //qDebug() << "invalid package of " << imageQueue.getName() << " = " << invalidPackage++ << "H264 package size = " << rtpSize ;
                }

                av_free(outBuffer);
                sws_freeContext(swsContext);
            }
        }

        av_frame_unref(avFrame);
        av_free(avFrame);
        av_free_packet(&avPacket);
        delete[] data;
    }
    return image;
}

void RTCSplitter::decoderOpen() {
    //    av_log_set_level(AV_LOG_QUIET);
    //    av_register_all();

    avCodec = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!avCodec) {
        // TODO
        qDebug()<<"Codec not found\n";
        exit(1);
    }
    avCodecContext = avcodec_alloc_context3(avCodec);
    if (!avCodecContext) {
        // TODO
        qDebug() << "Could not allocate video codec context\n";
        exit(1);
    }
    if (avCodec->capabilities & CODEC_CAP_TRUNCATED) {
//        avCodecContext->flags || CODEC_FLAG_TRUNCATED;
    }
    if (avcodec_open2(avCodecContext, avCodec, NULL) < 0) {
        // TODO
        qDebug() <<   "Could not open codec\n";
        exit(1);
    }

    avCodecContext->thread_count = 4;
    avCodecContext->thread_type = FF_THREAD_FRAME;

    //    avCodecContext->thread_type = 2;
    //    avCodecContext->flags2|=CODEC_FLAG2_FAST;

//    avCodecContext->flags2 |= CODEC_FLAG2_CHUNKS;
    //    if(avCodec->capabilities & CODEC_FLAG_LOW_DELAY){
    //        avCodecContext->flags|=CODEC_FLAG_LOW_DELAY;
    //    }
}

void RTCSplitter::decoderClose() {
    if (avCodecContext) {
        avcodec_close(avCodecContext);
        av_free(avCodecContext);
    }
}

