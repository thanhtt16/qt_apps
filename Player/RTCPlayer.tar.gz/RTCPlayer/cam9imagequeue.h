#ifndef CAM9IMAGEQUEUE_H
#define CAM9IMAGEQUEUE_H

#include <QMap>
#include <QImage>
#include <QMutex>
#include <QThread>
#include <QDebug>
#include <QException>
#include <QDateTime>

class Cam9ImageQueue
{
private:
    QMap<long, QImage> hashmap;
    QMutex queueUpdate;
    QString name = "Image Queue";
    long lastImageKey = 0.0;
    int timeWait = 40;
    QImage dequeueImage;

public:
    Cam9ImageQueue();
    QImage dequeue();
    void enqueue(long timestamp, QImage newImage);
    QString getName() const;
    void setName(const QString &value);
    void empty();
    int getSize() { int size; queueUpdate.lock(); size=hashmap.size(); queueUpdate.unlock(); return size;}
    long getTimeWait();
    QImage getDequeueImage();
};

#endif // CAM9IMAGEQUEUE_H
