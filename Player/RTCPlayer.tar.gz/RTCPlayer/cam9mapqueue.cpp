#include "cam9mapqueue.h"

Cam9MapQueue::Cam9MapQueue()
{
    this->name = name;
    this->dequeueIndex = 0;
}

quint64 Cam9MapQueue::getNextPakageNumber()
{
    return dequeueIndex;
}

QString Cam9MapQueue::getName() const
{
    return name;
}

void Cam9MapQueue::setName(const QString &value)
{
    name = value;
}

void Cam9MapQueue::updateLastLinkQueue(quint64 linkIndex) {
    queueUpdate.lock();
    lastLinkIndex = linkIndex;
    quint64 distance = lastLinkIndex - dequeueIndex;
    if (distance < 0) {
        dequeueIndex = lastLinkIndex-5;
    } else {
        while ((hashmap.size() > 0) && (lastLinkIndex - dequeueIndex > 5)) { // keep at most 5 waiting link
            hashmap.take(dequeueIndex);
            dequeueIndex++;
        }
    }
    queueUpdate.unlock();
}

void Cam9MapQueue::enqueue(quint64 index, QByteArray rtpData) {
    int size = getSize();
    int fps = 25;


    queueUpdate.lock();
    if (index  >= dequeueIndex)
    {
        hashmap.insert(index, rtpData);
    }
    else {
        qDebug() << getName() << "DROP!! incomming index=" << index << " dequeue index=" << dequeueIndex;
    }
    queueUpdate.unlock();

    if (size > 5 * fps) {
        QThread::msleep(1000);
        qDebug() << getName() << " size=" << size << " .... EMPTY queue";
        empty();
        dequeueIndex = lastLinkIndex;
    }
}

QByteArray Cam9MapQueue::dequeue() {
    QByteArray rtpData;
    if(name.contains("10"))
        qDebug() << name << "KEY DEQUEUE CURRENT" << dequeueIndex << "KEYS" << hashmap.keys();

    int size = getSize();
    queueUpdate.lock();
    rtpData = hashmap.take(dequeueIndex);
    if (!rtpData.isNull() && !rtpData.isEmpty()) {
        if (size > 10)
            qDebug() << "Cam9MapQueue::DEQUEUE" << getName() << " count=" << size;
        dequeueIndex++;
    }
    queueUpdate.unlock();
    return rtpData;
}


void Cam9MapQueue::next() {
    queueUpdate.lock();
    hashmap.remove(dequeueIndex);
    dequeueIndex++;
    queueUpdate.unlock();
}

void Cam9MapQueue::empty() {
    queueUpdate.lock();
    int size = hashmap.size();
    if (size > 0)
        hashmap.clear();
    dequeueIndex = 0;
    queueUpdate.unlock();
}
