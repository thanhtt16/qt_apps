﻿#ifndef RTCPLAYERWIDGET_H
#define RTCPLAYERWIDGET_H

#include <QBuffer>
#include <QByteArray>
#include <QElapsedTimer>
#include <QFile>
#include <QLabel>
#include <QMovie>
#include <QPushButton>
#include <QQueue>
#include <QRunnable>
#include <QThread>
#include <QThreadPool>
#include <QTimer>
#include <QVBoxLayout>
#include <QWidget>
#include <PacModel/control.h>

#include "RTCSplitter.h"
#include "RTCRender.h"
#include "RTCSocket.h"
#include "RTCDownloader.h"
#include "cam9mapqueue.h"
#include "message.h"
#include "Camera/camitem.h"

#include <QMutex>

class RTCSocket;
class RTCDownloader;
class RTCSplitter;
class RTCReceiver;
class RTCRender;
class RTCRenderWidget;

enum RTCPlayerState {
    RTCPS_Loading,
    RTCPS_Playing,
    RTCPS_Paused,
    RTCPS_Stopped
};

class RTCPlayer : public QObject {
    Q_OBJECT

private:
    QWidget *zone = Q_NULLPTR;
    QWidget *topbarSpaceHolder;
    QWidget *videoZone;

    AppMessage Message;
    QVBoxLayout *mainLayout;

    QNetworkAccessManager *naManager;
    RTCDownloader *rtpDownloader;

    // Streamer
    RTCSocket *pRTCSocket; // live stream manager :)


    RTCSplitter *pRTCSplitter;
    RTCRender *pRTCRenderer;
    RTCRenderWidget *pRTCRendererWidget;

    Cam9MapQueue rtpQueue;
    Cam9ImageQueue imageQueue;


    QString sourceUrl = "";
    bool isAutoPlay = true;
    bool isAutoReconnect = true;
    QString playerName;

    CamItem *camItem = Q_NULLPTR;
    CamItemType type;

public:
    RTCPlayer(QWidget *zone);
    ~RTCPlayer();

    //void rtcPlayerOpen(QString source);
    void startWorking();
    void stopWorking();

    bool getIsAutoReconnect();
    void setIsAutoReconnect(bool value);

    bool getIsAutoPlay() const;
    void setIsAutoPlay(bool value);
    QString getPlayerName() const { return playerName; }
    void setPlayerName(QString value) { playerName = value; }
    void wheelEventZoomVideo(QVariant *dataStruct);
    void eventMoveVideo(QVariant *dataStruct);

    Cam9MapQueue& getRtpQueue() { return rtpQueue; }
    Cam9ImageQueue& getImageQueue() { return imageQueue; }
    RTCSocket* getPRTCSocket()  { return pRTCSocket; }


    RTCSplitter *getPRTCSplitter() const;

    QString getSourceUrl() const;
    void newAction(int message, QVariant *attachment);
    void setSourceUrl(const QString &value);
    void playSource();
    void onDownloadNbtpLink(quint64 linkIndex, QString url);

    RTCDownloader *getRtpDownloader() const;

    bool getShouldPlayLive() const;

    QNetworkAccessManager *getNaManager() const;


    CamItemType getType() const;

public Q_SLOTS:
    void onSocketConnected();
    void onSocketDisconnected();

    void onShowLoadingSign();
    void onShowPlayerLayer();
    void onShowWallLayer();

    void onSetPlayerDisplayName(QString displayName) {
        this->playerName = displayName;
        qDebug() <<Q_FUNC_INFO << "NAME PLAYER " << displayName;
    }
protected:
    bool eventFilter(QObject *watched, QEvent *event);

Q_SIGNALS:
    void showLoadingSign();
    void showPlayerLayer();
    void showWallLayer();

};

#endif  // RTCPLAYERWIDGET_H
