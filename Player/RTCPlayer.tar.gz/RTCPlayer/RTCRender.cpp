﻿#include "RTCRender.h"

RTCRender::RTCRender(RTCPlayer *rtcPlayer) {
    this->pRTCPlayer = rtcPlayer;
    this->setObjectName("Render");
}

RTCRender::~RTCRender() {
}

void RTCRender::setRendererWidget(RTCRenderWidget *value) {
    rendererWidget = value;
}

RTCRenderWidget* RTCRender::getRendererWidget() const {
    return rendererWidget;
}

void RTCRender::startWorking() {
//    isShowLoading = true;
//    qDebug() << "RTCRender::startWorking";
//    Cam9ImageQueue& imageQueue = this->pRTCPlayer->getImageQueue();
//    imageQueue.empty();
    if (!isRunning()) {
        QThread::start();
    }
}

void RTCRender::stopWorking() {
//    isShowLoading = true;
//    qDebug() << "RTCRender::stopWorking";
//    this->pRTCPlayer->getImageQueue().empty();
    //    QThread::quit();
}

//    void RTCRender::run() {
//        int refreshRate = 40;
//        QString playerName = "Player " + this->pRTCPlayer->getPlayerName();
//        qDebug() << playerName <<  "::RTCRender::RUNING ";
//        Cam9ImageQueue& imageQueue = this->pRTCPlayer->getImageQueue();
//        imageQueue.setName("Image Queue of " + playerName);

//        while (isRunning()) {
//            // reach the low water mark
//            //        if (imageQueue.getSize() == 0) {
//            //            Q_EMIT showLoadingSign();
//            //            while (isRunning() && imageQueue.getSize() < 2) {
//            //                QThread::msleep(20);
//            //            }
//            //            Q_EMIT showPlayerLayer();
//            //        }



//            imageQueue.dequeue();
//            QImage image = imageQueue.getDequeueImage();
//            if (!image.isNull()) {
//                if (isShowLoading){
//                    Q_EMIT showPlayerLayer();
//                    isShowLoading = false;
//                }

//                rendererWidget->onDrawImageFromRenderer(image);
//            }else{
//    //            if(imageQueue.getSize() == 0){
//    //                if(imageQueue.getSize() > 5) continue;
//    //                if(!isShowLoading){
//    //                    qDebug() << "showLoadingSign" << imageQueue.getSize();
//    //                    Q_EMIT showLoadingSign();
//    //                    isShowLoading = true;
//    //                }
//    //            }
//            }

//            int size = imageQueue.getSize();

//            if (size >= 10) {
//                refreshRate = 20; // 5 times faster
//            } else {
//                refreshRate = imageQueue.getTimeWait();
//            }
//            if(size  > 2*fps ){
//                refreshRate = 8;
//            }
//            QThread::msleep(refreshRate);
//        }
//        qDebug() << playerName << "::RTCRender::STOPPED ";
//    }


void RTCRender::run() {
    static int fps = 25; // frames per second
    static int renderCost = 0; // miliseconds
    int refreshRate = 40;
    bool gopStarted = false;
    QImage image;
    QString playerName = "Player " + this->pRTCPlayer->getPlayerName();
    Cam9ImageQueue& imageQueue = this->pRTCPlayer->getImageQueue();
    imageQueue.setName("Image Queue of " + playerName);

    qDebug() << playerName <<  "::RTCRender::RUNING ";

    while (1) {
        QImage image = imageQueue.dequeue();
        if (!image.isNull()) {
            if (freeTime) {
                freeTime = 0;
                Q_EMIT showPlayerLayer();
            }
            rendererWidget->onDrawImageFromRenderer(image);
        } else {
            freeTime++;
            if (freeTime == fps) {
                freeTime=0;
                Q_EMIT showLoadingSign();
            }
        }

        int size = imageQueue.getSize();
        if (size > 5*fps) {
            refreshRate = 8;
        } else {
            if (size < 1*fps) {
                refreshRate = 40;
            }
            else {
                refreshRate = 8;
            }
        }

        QThread::msleep(refreshRate);
    }
    qDebug() << playerName << "::RTCRender::STOPPED ";
}
