#ifndef H264DECODER_H
#define H264DECODER_H

#include <QObject>
#include <QPixmap>
#include <QDebug>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavcodec/mediacodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
#include <libavutil/pixdesc.h>
#include <libavutil/pixfmt.h>
#include <libswscale/swscale.h>
}

class H264Decoder : public QObject
{
    Q_OBJECT
public:
    H264Decoder(QObject *parrent = nullptr);
    void storePicture(std::vector<unsigned char>& res);

    virtual ~H264Decoder();
protected:
    AVCodec* m_decoder;
    AVCodecContext* m_decoderContext;
    int m_got_picture;
    AVFrame* m_picture;
public Q_SLOTS:

     void decodeFrame(long timestamp, QByteArray rtpPackage);

Q_SIGNALS:
    //sended when we have new decoded frame
    void newDecodedFrame(long timestamp,QImage img );
    void criticalError(QString err);
};

#endif // H264DECODER_H
