#include "RTCDownloader.h"

RTCDownloader::RTCDownloader(RTCPlayer *rtcPlayer, QNetworkAccessManager *manager)
{
    pRTCPlayer = rtcPlayer;
    naManager = manager;
    connect(naManager, &QNetworkAccessManager::finished, this, &RTCDownloader::onDownloadFinished);
}

RTCDownloader::~RTCDownloader()
{
}

void RTCDownloader::onReceiveDowloadRTCData(quint64 linkIndex, QString url)
{
    QNetworkRequest req(url);
    QNetworkReply *reply = naManager->get(req);
    //connect(reply, SIGNAL(&QNetworkReply::downloadProgress(qint64,qint64)), this, SLOT(&RTCDownloader::download_progress(qint64, qint64)));
    replyToIndex[reply] = linkIndex;
    //qDebug() << "DOWNLOAD:::Start" << linkIndex << "] = " << url;
    Cam9MapQueue& rtpQueue =this->pRTCPlayer->getRtpQueue();
    rtpQueue.updateLastLinkQueue(linkIndex);
}

void RTCDownloader::download_progress(qint64, qint64) {
    //    quint64 linkIndex = replyToIndex.take(reply);
    //    if (reply->bytesAvailable() > 0) {
    //        bool ret;
    //       // read header 12 bytes
    //       QByteArray headerBytes = reply->read(12);
    //       int payloadSize = headerBytes.mid(0, 2).toHex().toInt(&ret,16);
    //       double timestamp =  headerBytes.mid(2, 8).toDouble(&ret);
    //       int index = headerBytes.mid(10, 2).toHex().toInt(&ret,16);

    //       // read 1 rtp package
    //       int lengthOfH264RawData = payloadSize - 10;
    //       QByteArray h264Raw = reply->read(lengthOfH264RawData);
    //       onReceiveDownloadedData(index, headerBytes + h264Raw);
    //    }
}

void RTCDownloader::onDownloadFinished(QNetworkReply *reply) {
    quint64 linkIndex = replyToIndex.take(reply);
    if (reply->bytesAvailable() > 0) {
        QByteArray byteArrayReceived = reply->readAll();
        onReceiveDownloadedData(linkIndex,byteArrayReceived);
        //      if(linkIndex == 0 || linkIndex == 1 || linkIndex == 3 ) {
        //          QByteArray bytearray = reply->readAll();
        //          qDebug() << "DOWLOAD _ PACKAGE _FIRST _ SUCCESS" << bytearray.size();
        //          bool ok;
        //          QList<int> listvalue;
        //          for (int index = 0; index < bytearray.size(); ++index) {
        //              int value  = bytearray.mid(index,1).toHex().toInt(&ok,16);
        //              listvalue.append(value);
        //              qDebug() << "LIST VALUE" <<  listvalue << "\n";
        //              qDebug() << "************************************* END -***************************************";
        //          }
        //      }
    } else {
        onReceiveDownloadDataFailed(linkIndex, reply->errorString());
    }
    reply->deleteLater();
}

void RTCDownloader::resetInternalState() {
    replyToIndex.clear();
}

void RTCDownloader::onReceiveDownloadedData(quint64 linkIndex, QByteArray payload) {

    QString playerName = "Player " + this->pRTCPlayer->getPlayerName();
    Cam9MapQueue& rtpQueue =this->pRTCPlayer->getRtpQueue();
    rtpQueue.enqueue(linkIndex, payload);
    //    qDebug() <<Q_FUNC_INFO << "onReceiveDownloadedData" <<  linkIndex;

    //    if(playerName.contains("0") == true){
    //        qDebug() <<Q_FUNC_INFO << "onReceiveDownloadedData" <<  linkIndex;
    //    }
}

void RTCDownloader::onReceiveDownloadDataFailed(quint64 linkIndex, QString errorString) {
    Q_UNUSED(linkIndex)
    Q_UNUSED(errorString)

    //    QString playerName = "Player " + this->pRTCPlayer->getPlayerName();
    //    qDebug() << playerName << " Thread: " << this->thread()
    //             << "RTCDownloader onReceiveDownloadDataFailed - linkIndex: " << linkIndex
    //             << " error: "  << errorString
    //             << " networkAccessible: " << naManager->networkAccessible();
}
