#include "cam9imagequeue.h"

long Cam9ImageQueue::getTimeWait()
{
    long delay;
    queueUpdate.lock();
    delay = timeWait;
    queueUpdate.unlock();
    return delay;
}

QImage Cam9ImageQueue::getDequeueImage()
{
    QImage image;
    queueUpdate.lock();
    //    dequeueImage = this->hashmap.take(this->hashmap.firstKey());
    image = dequeueImage;
    queueUpdate.unlock();
    //    qDebug()<< QDateTime::currentMSecsSinceEpoch() << this << Q_FUNC_INFO << image.size();
    return image;
}

Cam9ImageQueue::Cam9ImageQueue()
{
}

void Cam9ImageQueue::enqueue(long timestamp, QImage newImage) {
    int size = getSize();
    int fps = 25;
    if (size > 10*fps) {
        QThread::msleep(1000);
        qDebug() << getName() << "::Image Enqueue size=" << size << " .... EMPTY queue";
        // empty();
    }

    if(name.contains("10") == true){
        qDebug() << timestamp;
    }

    queueUpdate.lock();
    hashmap.insert(timestamp, newImage);
    queueUpdate.unlock();
}

QString Cam9ImageQueue::getName() const
{
    return name;
}

void Cam9ImageQueue::setName(const QString &value)
{
    name = value;
}

QImage Cam9ImageQueue::dequeue() {
    QImage image;
    long currentImageKey;
    queueUpdate.lock();
    //    if(name.contains("10") == true){

    //        qDebug() << name <<  "ENQUEUE"<<"SISE" << hashmap.size()  << "KEYS" << hashmap.keys();

    //    }
    if(hashmap.size() >0 ) {
        currentImageKey = hashmap.firstKey();
        //        if(hashmap.size() > 10){
        //        qDebug() << name <<  "DEQUEUE"<<"SISE" << hashmap.size()  << "KEY CURRENT" << currentImageKey << "KEYS" << hashmap.keys();
        //        }
        image = hashmap.take(currentImageKey);
    }

    if (!this->dequeueImage.isNull()) {
        long delay = currentImageKey - this->lastImageKey;
        if (delay < 0 || delay > 40) {
            this->timeWait = 40;
        } else {
            this->timeWait = delay;
        }
        this->lastImageKey = currentImageKey;
    }
    queueUpdate.unlock();
    return image;
}

void Cam9ImageQueue::empty() {
    queueUpdate.lock();
    hashmap.clear();
    lastImageKey = 0;
    queueUpdate.unlock();
}
