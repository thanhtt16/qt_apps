#include "h264decoder.h"

H264Decoder::H264Decoder( QObject *parent)
    : m_decoder(nullptr), m_decoderContext(nullptr),
      m_got_picture(0), m_picture(nullptr)
{
    avcodec_register_all();
    m_decoder = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!m_decoder)
    {
        QString str = QString("Can't find H264 decoder!");
        Q_EMIT criticalError(str);
    }
    m_decoderContext = avcodec_alloc_context3(m_decoder);

//    if (m_decoder->capabilities & CODEC_CAP_TRUNCATED)
//        m_decoderContext->flags |= CODEC_FLAG_TRUNCATED;


    //we can receive truncated frames
    m_decoderContext->flags2 |= CODEC_FLAG2_CHUNKS;
    m_decoderContext->thread_count = 4;//TODO: random value. May be changing can make decoding faster

    AVDictionary* dictionary = nullptr;
    if (avcodec_open2(m_decoderContext, m_decoder, &dictionary) < 0)
    {
        QString str = QString("Failed to open decoder!");
        Q_EMIT criticalError(str);
    }
    m_picture = av_frame_alloc();
    qDebug() << "H264 Decoder successfully opened";
}



H264Decoder::~H264Decoder()
{
    qDebug() << "ACHTUNG!!! H264Decoder deleted!!!\r\n\r\n";
    if (m_decoderContext)
    {
        avcodec_close(m_decoderContext);
        delete m_decoderContext;
    }
}



void H264Decoder::decodeFrame(long timestamp, QByteArray rtpPackage)
{

    int rtpSize = rtpPackage.size();
    quint8 *data = new quint8[rtpSize];
    memcpy(data, rtpPackage.constData(), rtpSize);

    AVPacket m_packet;
    //allocate packet memory
    av_new_packet(&m_packet, rtpSize);
    av_init_packet(&m_packet);
    m_packet.size = rtpSize;
    m_packet.data = data;

    if(m_packet.size > 0)
    {
        qDebug() << m_packet.size << m_packet.data;
        int got_picture = 2;
        int len = avcodec_decode_video2(m_decoderContext, m_picture, &got_picture, &m_packet);
        if (len < 0)
        {
            QString err("Decoding error");
            qDebug() << err;
            return ;
        }
        qDebug() << "LEN" <<len << got_picture;

        if (got_picture)
        {
            qDebug() << "H264Decoder: frame decoded!";
            std::vector<unsigned char> result;
            this->storePicture(result);

            if ( m_picture->format == AV_PIX_FMT_YUV420P )
            {
                static SwsContext *m_swsCtx = NULL;
                QImage frame_img = QImage(m_picture->width, m_picture->height, QImage::Format_RGB888);
                m_swsCtx = sws_getCachedContext ( m_swsCtx, m_picture->width,
                    m_picture->height, AV_PIX_FMT_YUV420P,
                    m_picture->width, m_picture->height,
                    AV_PIX_FMT_RGB24, SWS_GAUSS,
                    NULL, NULL, NULL );
                uint8_t *dstSlice[] = { frame_img.bits() };
                int dstStride = frame_img.width() * 3;
                if (sws_scale ( m_swsCtx, m_picture->data, m_picture->linesize,
                    0, m_picture->height, dstSlice, &dstStride ) != m_picture->height )
                {
                    qDebug() << "PIZDETS!!!";
                    exit(-5);
                }
                qDebug() << "New decoded image AV_PIX_FMT_YUV420P !";
                Q_EMIT newDecodedFrame(timestamp,frame_img);
            }
            else if (m_picture->format == AV_PIX_FMT_RGB32)
            {
                QImage img = QImage(result.data(), m_picture->width, m_picture->height, QImage::Format_RGB32);
                qDebug() << "New decoded image AV_PIX_FMT_RGB32!";
                Q_EMIT newDecodedFrame(timestamp,img);
            }
            else if (m_picture->format == AV_PIX_FMT_RGB24)
            {
                QImage img = QImage(result.data(), m_picture->width, m_picture->height, QImage::Format_RGB888);
                qDebug() << "New decoded image AV_PIX_FMT_RGB24!";
                Q_EMIT newDecodedFrame(timestamp,img);
            }
            else
            {
                QString err = QString( "Unsupported pixel format! Can't create QImage!");
                qDebug() << err;
                Q_EMIT criticalError(err);
                return;
            }
        }
        m_packet.size -= len;
        m_packet.data += len;
    }
}

void H264Decoder::storePicture(std::vector<unsigned char>& res)
{
    for (size_t i = 0; i < AV_NUM_DATA_POINTERS; i++)
    {
        std::copy(m_picture->data[i], m_picture->data[i] +
            m_picture->linesize[i]*m_picture->height, std::back_inserter(res));
    }
}
